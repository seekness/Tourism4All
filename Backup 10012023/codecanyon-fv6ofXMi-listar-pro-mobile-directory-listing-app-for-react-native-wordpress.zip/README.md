# Information
- [Document](https://passionui.com/docs/listar-pro)
- [Support](https://passionui.com/support)
- [License](https://passionui.com/license)

# License
### When you purchase Regular License ?
Use, by you or one client, in a single end product which end users are not charged for

- You’re a freelancer and do customize for your single end customer
- You’re just want to researching about this project
- The end user access and use your project as free without be charged or sold any packages/subscription

Example: You’re using the project mobile app and making it for free as use. The application just show information for end user. The user access your application won’t be charged or pay the money for use

Read more detail about [Regular License](https://codecanyon.net/licenses/terms/regular) from Envato

### When you purchase Extended License ?
Use, by you or one client, in a single end product which end users can be charged for.

- You’re doing business on the project
- You use the project then customize it become your project or for your end customer
- The end user use your project and pay for use like subscription or pay for weekly/monthly for use
- You’re using the project and selling the service/package on it

Example: You’re using the template mobile app and making the booking application service like hotel booking, real estate booking. The end user has to register an account and pay the money monthly/yearly to use your application service.

You’re selling the package via the application service and the end user have to buy it for use your service for submit their hotel, real estate information

You’re earning and monetizing money via the project.
Read more detail about [Extended License](https://codecanyon.net/licenses/terms/extended) from Envato
