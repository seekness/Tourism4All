# Description
Listar is Directory Listing & Classifieds for Wordpress sites
Provides solution for help you organize your listings.
It’s suitable for many kind of mobile directory listing like store locator, tourists or city guide, event & attraction places, property directory.

# Documentation
[https://passionui.com/docs/listar-wp](https://passionui.com/docs/listar-wp)

# Support
[https://passionui.com/support](https://passionui.com/support)

# Mobile Apps
Check more mobile app support and connect with Listar WP Wordpress site

- [Listar FluxPro](https://codecanyon.net/item/listar-fluxpro-mobile-directory-listing-app-for-flutter-wordpress/28292407)
- [Listar Pro](https://codecanyon.net/item/listar-pro-mobile-directory-listing-app-for-react-native-wordpress/29024132)

Both Listar FluxPro and Listar Pro are supporting:
- Connect Wordpress backend via REST API
- All data on web can be showed on the mobile app
- Support both Android/iOS
- Listar FluxPro was made with Flutter Framework by Google
- Listar Pro was made with React Native Framework by Facebook

