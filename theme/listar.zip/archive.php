<?php
get_header();

if(get_post_type() === Listar_Theme::$post_type || !get_post_type()) {
    get_template_part('template-parts/listar/archive');
} else {
    get_template_part('template-parts/post/archive');
}
get_footer();

?>
<script type="text/javascript">
    function parse_query_string(query) {
        var vars = query.split("&");
        var query_string = {};

        for (var i = 0; i < vars.length; i++) {
            var pair = vars[i].split("=");
            var key = decodeURIComponent(pair[0]);
            var value = decodeURIComponent(pair[1]);

            if (typeof query_string[key] === "undefined") { // If first entry with this name
                query_string[key] = decodeURIComponent(value);
            } else if (typeof query_string[key] === "string") { // If second entry with this name
                var arr = [query_string[key], decodeURIComponent(value)];
                query_string[key] = arr;
            } else { // If third or later entry with this name
                query_string[key].push(decodeURIComponent(value));
            }
        }

        return query_string;
    }

    var display_number = 5;

    if ($('.cat-list').length > display_number) {
        $('.cat-list:gt(' + (display_number - 1) + ')').hide();
        $('.cat-more').show();
    }

    $('.cat-more').on('click', function() {
        $('.cat-list:gt(' + (display_number - 1) + ')').toggle();
        $(this).text() === 'More' ? $(this).text('Less') : $(this).text('More');
    });

    if ($('.fac-list').length > display_number) {
        $('.fac-list:gt(' + (display_number - 1) + ')').hide();
        $('.fac-more').show();
    }

    $('.fac-more').on('click', function() {
        $('.fac-list:gt(' + (display_number - 1) + ')').toggle();
        $(this).text() === 'More' ? $(this).text('Less') : $(this).text('More');
    });

    $(document).ready(function() {
        create_slider_range($('#price_range'), function(min, max) {
            document.getElementById('price_range_start').innerHTML = min;
            document.getElementById('price_range_end').innerHTML = max;
            $('input:hidden#price_min').val(min);
            $('input:hidden#price_max').val(max);
        });
    });

    $(document).ready(function() {
        $('#location-filtering').multiselect({
            enableFiltering: true,
            maxHeight: 500
        });

        $('.multiselect-container input[type="checkbox"]').each(function(index, input) {
            console.log('index', index);
            console.log('input', input);
            $(input).after("<span class='custome-icon'></span>");;
        });
    });
</script>