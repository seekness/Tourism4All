<?php get_header(); ?>
    <div class="container content-grid">
        Author Page
    </div>
<?php get_footer(); ?>