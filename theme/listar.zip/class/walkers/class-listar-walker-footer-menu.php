<?php
/**
 * Listar Nav Menu Walker to create HTML for list of pages
 */
class Listar_Walker_Footer_Menu extends Walker_Nav_Menu {
    public function __construct() {
        add_filter('nav_menu_link_attributes' , [$this, 'nav_menu_link_attributes'] , 10 , 4);
    }
    /**
     * Add customize class for li element
     * @param array $atts
     * @param WP_Post $item
     * @param stdClass $args
     * @param int $depth
     * @return array
     * @since 1.0.0
     */
    public function nav_menu_link_attributes($atts, $item, $args, $depth) {
        $atts['class'] = '';
        return $atts;
    }
}
