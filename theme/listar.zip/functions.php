<?php
/*
Theme Name: Listar WP
Theme URI: https://listarapp.com
Author: PassionUI Team
Author URI: https://codecanyon.net/user/passionui
Description:
Version: 1.0.1
License: GNU General Public License v2 or later
License URI: LICENSE
Tags: business directory, car dealer, classified listing, directory listing, event listing, directory listing, hotel listing, listing app, mobile app, real estate listing, shopping listing, store locator
Text Domain: listar_wp

This theme, like WordPress, is licensed under the GPL.
Use it to make something cool, have fun, and share what you've learned with others.
*/

require get_template_directory() . '/inc/helper-functions.php';
require get_template_directory() . '/class/walkers/class-listar-walker-nav-menu.php';
require get_template_directory() . '/class/walkers/class-listar-walker-footer-menu.php';

class Listar_Theme
{
    /**
     * Plugin version
     *
     * @var string
     */
    static $version = '1.0.1';

    /**
     * Customize post type
     * @var string
     */
    static $post_type = 'listar';

    /** Refers to a single instance of this class. */
    private static $instance = null;

    /**
     * Initializes the Listar_Theme() class
     *
     * Checks for an existing Listar_Theme() instance
     * and if it doesn't find one, creates it.
     */
    public function __construct()
    {
        add_action('after_setup_theme', [$this, 'after_setup_theme']);
        // Register script & style
        add_action('wp_enqueue_scripts', [$this, 'load_scripts']);

        add_action('pre_get_posts', [$this, 'pre_get_posts'], 10, 1);

        add_action('wp_head', [$this, 'wp_head']);

        add_action('login_head', [$this, 'login_head']);        

        // Admin page
        if(is_admin()) {
            // Admin Header
            add_action('admin_head', [$this, 'admin_head']);

            // One Click Demo
            $this->ocdi();
        }

        // Sidebar
        add_action('widgets_init', function () {
            $this->register_sidebar();
        });
    }

    /**
     * Creates or returns an instance of this class.
     *
     * @return  Listar_Theme A single instance of this class.
     */
    public static function get_instance()
    {
        if (null == self::$instance) {
            self::$instance = new self;
        }
        return self::$instance;
    }

    /**
     * Fires after the theme is loaded.
     * @since v1.0.0
     */
    public function after_setup_theme()
    {
        $this->theme_support();
        $this->register_nav_menus();
    }

    /**
     * Theme support function
     */
    public function theme_support()
    {
        // Customize Title
        add_theme_support('title-tag');

        // Customize Logo
        add_theme_support('custom-logo');

        // Customize search
        add_theme_support('search-form');

        // customize Header
        add_theme_support( 'custom-header', [
            'default-image'      => get_template_directory_uri() . '/assets/img/header-image.jpg',
            'default-text-color' => '000',
            'width'              => 1280,
            'height'             => 960,
            'flex-width'         => true,
            'flex-height'        => true,
        ]);

        // Feed Link
        add_theme_support( 'automatic-feed-links' );

        // Threaded comment reply styles.
        if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
            wp_enqueue_script( 'comment-reply' );
        }

        // Set content-width.
        global $content_width;
        if ( ! isset( $content_width ) ) {
            $content_width = 580;
        }

        // Body Open
        if ( function_exists( 'wp_body_open' ) ) {
            //wp_body_open();
        } else {
            //do_action( 'wp_body_open' );
        }
    }

    /**
     * WP Head function
     */
    public function wp_head()
    {
        $this->favicon_support();
    }

    /**
     * Login Head function
     */
    public function login_head()
    {
        $this->favicon_support();
    }

    /**
     * Admin Head function
     */
    public function admin_head()
    {
        $this->favicon_support();
    }

    /**
     * Get default favicon if user does not set yet function
     */
    public function favicon_support()
    {
        if (!has_site_icon() && !is_customize_preview()) {
            echo '<link rel="icon" type="image/png" href="' . get_template_directory_uri() . '/assets/img/icon_40pt.png">';
        }
    }

    /**
     * The plugin items for theme need
     */
    public function ocdi()
    {
        add_filter( 'ocdi/import_files', [$this, 'ocdi_import_files'] );
    }

    /**
     * Pre define demo import files
     * @return array
     */
    public function ocdi_import_files()
    {
        return [
            [
                'import_file_name'           => 'Demo Content',
                'import_file_url'            => 'https://listarapp.com/ocdi/demo-content.xml',
                'import_widget_file_url'     => 'https://listarapp.com/ocdi/demo-widgets.wie',
                'import_preview_image_url'   => 'https://listarapp.com/ocdi/preview_import.png',
                'preview_url'                => 'https://listarapp.com',
            ]
        ];
    }

    /**
     * Register navigation menu
     * @since v1.0.0
     */
    public function register_nav_menus()
    {
        register_nav_menus([
            'header-menu' => __('Header Menu', 'listar_wp'), // Top Menu
            'footer-menu-col-2' => __('Footer Menu Column 2', 'listar_wp'), // Footer Menu
            'footer-menu-col-3' => __('Footer Menu Column 3', 'listar_wp'), // Footer Menu
        ]);
    }

    /**
     * Register sidebar
     * @since v1.0.0
     */
    public function register_sidebar()
    {
        // Recent Directory Thumb
        register_sidebar([
            'name'  => __('Listar Home Sidebar', 'listar_wp'),
            'id'  => 'listar-home-sidebar',
        ]);

        // Single Post
        register_sidebar([
            'name'  => __('Listar Detail Right Sidebar', 'listar_wp'),
            'id'  => 'listar-detail-right-sidebar',
        ]);

        register_sidebar([
            'name'  => __('Listar Left Sidebar', 'listar_wp'),
            'id'  => 'listar-left-sidebar',
        ]);
    }

    /**
     * Load assets & scripts
     */
    public function load_scripts()
    {
        $version = self::$version;
        // CSS
        wp_enqueue_style('passionui-css-light-slider', get_template_directory_uri() . '/assets/css/lightslider.css', array(), '1.0', 'all');
        wp_enqueue_style('passionui-css-multi-select', get_template_directory_uri() . '/assets/css/jquery.multiselect.css', array(), '1.0', 'all');
        wp_enqueue_style('passionui-css-fontawesome', get_template_directory_uri() . '/assets/lib/fontawesome/5.12.0/css/all.css', array(), '1.0', 'all');
        wp_enqueue_style('passionui-css-bootstrap-select', get_template_directory_uri() . '/assets/lib/bootstrap-multiselect/css/bootstrap-multiselect.css', array(), '1.0', 'all');
        wp_enqueue_style('passionui-css-fontawesome-icon', get_template_directory_uri() . '/assets/lib/bootstrap/css/bootstrap.min.css', array(), '4.5.2', 'all');
        wp_enqueue_style('passionui-comment-rating-styles', get_template_directory_uri() . '/assets/lib/fontawesome/3.2.1/css/font-awesome.css', array(), '3.2.1', 'all');
        wp_enqueue_style('passionui-google-fonts-raleway', 'https://fonts.googleapis.com/css?family=Raleway:300,400,500,600,700,800,900');
        wp_enqueue_style('passionui-css-listar', get_template_directory_uri() . '/assets/css/listar.css', array(), $version, 'all');

        // JS
        wp_enqueue_script('passionui-js-fontawesome', get_template_directory_uri() . '/assets/lib/fontawesome/5.12.0/js/all.js', array(), '1.0', true);
        wp_enqueue_script('passionui-js-jquery-3', get_template_directory_uri() . '/assets/js/jquery-3.4.1.js', array(), '3.4.1', true);
        wp_enqueue_script('passionui-js-range-slider', get_template_directory_uri() . '/assets/js/range-slider.js', array(), '1.0', true);
        wp_enqueue_script('passionui-js-listar', get_template_directory_uri() . '/assets/js/listar-script.js', array(), $version, true);
        wp_enqueue_script('passionui-js-light-slider', get_template_directory_uri() . '/assets/js/light-slider.js', array(), '1.0', true);
        wp_enqueue_script('passionui-js-popper', get_template_directory_uri() . '/assets/js/popper.js', array(), '1.16.0', true);
        // wp_enqueue_script('passionui-js-jquery', get_template_directory_uri() . '/assets/lib/jquery/jquery.min.js', array(), '3.3.1', true);
        wp_enqueue_script('passionui-js-bootstrap-multi', get_template_directory_uri() . '/assets/lib/bootstrap-multiselect/js/bootstrap-multiselect.js', array(), '1.0', true);
        wp_enqueue_script('passionui-js-scroll-bar', get_template_directory_uri() . '/assets/lib/perfect-scrollbar/perfect-scrollbar.min.js', array(), '1.0', true);
        wp_enqueue_script('passionui-js-bootstrap', get_template_directory_uri() . '/assets/lib/bootstrap/js/bootstrap.min.js', array(), '4.5.2', true);

        // get theme setting params
        wp_localize_script('passionui-js-listar', 'php_value', array(
            'control'   => listar_theme_option('skin_control'),
            'theme'     => listar_theme_option('dark_mode'),
            'color'     => listar_theme_option('skin')
        ));
    }

    /**
     * Customize URL filtering
     * @param WP_Query $query
     */
    public function pre_get_posts($query)
    {
        /**
         * Skip run the customize query
         */
        if (is_admin()) return;

        if (!$query->is_main_query()) return;

        if (isset($query->query['post_type']) && $query->query['post_type'] !== Listar_Theme::$post_type) return;

        $meta_query = $query->get('meta_query');
        $tax_query = $query->get('tax_query');

        if (!$meta_query) {
            $meta_query = [];
        }
        if (!$tax_query) {
            $tax_query = [];
        }

        // Tax Query
        $tax_query_val = [
            'category' => listar_get_request_parameter('category', 0),
            'feature' => listar_get_request_parameter('feature', 0),
            'location' => listar_get_request_parameter('location', 0)
        ];

        foreach ($tax_query_val as $key => $value) {
            if ($value) {
                $tax_query['tax_query'][] = [
                    'taxonomy' => Listar_Theme::$post_type . '_' . $key,
                    'field'    => 'term_id',
                    'terms'    => is_array($value) ? $value : absint($value)
                ];
            }
        }

        // Pricing Query
        $price_min = absint(listar_get_request_parameter('price_min', 0));
        if ($price_min > 0) {
            $meta_query[] = [
                'key'     => 'price_min',
                'value'   => $price_min,
                'type'    => 'numeric',
                'compare' => '>=',
            ];
        }

        $price_max = absint(listar_get_request_parameter('price_max', 0));
        if ($price_max > 0) {
            $meta_query[] = [
                'key'     => 'price_max',
                'value'   => $price_max,
                'type'    => 'numeric',
                'compare' => '<=',
            ];
        }

        // Color Query
        $color = listar_get_request_parameter('color');
        if ($color !== '') {
            $hash = substr($color, 0, 1);
            if ($hash !== '#') {
                $request['color'] = sprintf('#%s', $color);
            }
            $meta_query[] = [
                'key'     => 'color',
                'value'   => sanitize_text_field($color),
                'compare' => '=',
            ];
        }

        // Time Query
        $time = listar_get_request_parameter('time');
        if ($time) {
            $meta_query[] = [
                'key'     => 'opening_hour_1_start',
                'value'   => sanitize_text_field($time),
                'compare' => '>=',
            ];
        }

        $rating = listar_get_request_parameter('rating');
        if ($rating) {
            $meta_query[] = [
                'key'     => 'rating_avg',
                'value'   => sanitize_text_field($rating),
                'compare' => '>=',
            ];
        }

        // Sorting Query
        $sorting = listar_get_request_parameter('sorting', '');
        if ($sorting) {
            $sorting_exp = explode('_', $sorting);
            $order_by = $sorting_exp[0] . '_' . $sorting_exp[1];
            $order = $sorting_exp[2];

            $query->set('orderby', $order_by);
            $query->set('order', $order);
        }

        // Update meta query
        $query->set('meta_query', $meta_query);
        $query->set('tax_query', $tax_query);
    }
}

/**
 * Initialize the Listar Theme
 * @return Listar_Theme
 */
Listar_Theme::get_instance();
