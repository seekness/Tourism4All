<?php
if(!function_exists('listar_theme_option')) {
    /**
     * Get option
     * @param string $key
     * @return mixed|string|void
     */
    function listar_theme_option($key = '') {
        if(class_exists('Listar_Setting_Model')) {
            return Listar_Setting_Model::get_option($key);
        }

        return get_option(Listar_Theme::$post_type.'_'.$key);
    }
}

if(!function_exists('listar_get_terms')) {
    /**
     * Get list tax
     * @param string $tax_name
     * @param array $option
     * @return array|int|WP_Error|WP_Term[]
     */
    function listar_get_terms($tax_name = '', $option = []) {
        return get_terms(Listar_Theme::$post_type.'_'.$tax_name, $option);
    }
}

if (!function_exists('listar_the_rating_icon')) {
    /**
     * Show rating icon string
     * @param int $range
     * @param bool $echo
     * @return string
     */
    function listar_the_rating_icon($range = 5, $echo = true, $value = '')
    {
        if($value) {
            $rating = $value;
        } else {
            $rating = (int)get_post_meta(get_the_ID(), 'rating_avg', TRUE);
        }

        $result = str_repeat('<i class="fa fa-star" color="#fdc60a"></i>', $rating);
        $result .= str_repeat('<i class="fa fa-star" color="#9B9B9B"></i>', $range - $rating);
        if ($echo) {
            echo '<div class="star">' . $result . '</div>';
        }
        return '<div class="star">' . $result . '</div>';
    }
}

if (!function_exists('listar_the_categories_list')) {
    /**
     * echo the first category
     * @param string $before
     * @param string $after
     * @param bool $echo
     * @param bool $is_single
     * @return string
     */
    function listar_the_categories_list($before = '', $after = '', $echo = true, $is_single = true)
    {
        $categories = wp_get_post_terms(get_the_ID(), Listar_Theme::$post_type . '_category');
        $title = '';

        if (!empty($categories)) {
            if($is_single || count($categories) === 1) {
                $title = $categories[0]->name;
            } else {
                foreach ($categories as $key => $value) {
                    if(count($categories) === ($key + 1)) {
                        $title .= $value->name;
                    } else {
                        $title .= $value->name . ', ';
                    }
                }
            }
        } else {
            $title .= __('Undefined', 'listar_wp');
        }

        $title = $before . $title . $after;

        if ($echo) {
            echo ''.$title;
        } else {
            return $title;
        }
    }
}

if (!function_exists('listar_get_features')) {
    /**
     * Get feature list base on Post ID
     * @return array
     */
    function listar_get_features()
    {
        return wp_get_post_terms(get_the_ID(), Listar_Theme::$post_type . '_feature');
    }
}

if (!function_exists('listar_get_menu_by_location')) {
    /**
     * Get menu object by the location ID
     * @param $location
     * @return array|bool|mixed|WP_Error|WP_Term|null
     */
    function listar_get_menu_by_location($location)
    {
        if (empty($location)) return false;

        $locations = get_nav_menu_locations();
        if (!isset($locations[$location])) return false;

        return get_term($locations[$location], 'nav_menu');
    }
}

if (!function_exists('listar_get_request_parameter')) {
    /**
     * Gets the request parameter.
     *
     * @param string $key The query parameter
     * @param string $default The default value to return if not found
     *
     * @return     string|array  The request parameter.
     */
    function listar_get_request_parameter($key, $default = '')
    {
        // If not request set
        if (!isset($_REQUEST[$key]) || empty($_REQUEST[$key])) {
            return $default;
        }

        $result = NULL;
        if (is_array($_REQUEST[$key])) {
            foreach ($_REQUEST[$key] as $key => $value) {
                $result[] = strip_tags((string)wp_unslash($value));
            }
            return $result;
        } else {
            return strip_tags((string)wp_unslash($_REQUEST[$key]));
        }
    }
}

if (!function_exists('listar_get_permalink')) {
    /**
     * Build URL
     * - Support post_type query
     * @param array $arg
     * @param null $post_type
     * @return string
     */
    function listar_get_permalink($arg = [], $post_type = NULL)
    {
        $arg['post_type'] = $post_type ? $post_type : Listar_Theme::$post_type;
        $query_string = [];
        foreach ($arg as $key => $string) {
            $query_string[] = $key . '=' . strip_tags((string)wp_unslash($string));
        }

        return sprintf('%s/?%s', home_url(), implode('&', $query_string));
    }
}

if (!function_exists('listar_get_listing_url')) {
    /**
     * Get listing URL format base on the setting
     * - Support re-write mod
     * @param array $arg
     * @return string
     * @since 1.0.0
     */
    function listar_get_listing_url($arg = [])
    {
        $query_string = [];
        if(is_array($arg) && !empty($arg)) {
            foreach ($arg as $key => $string) {
                $query_string[] = $key . '=' . strip_tags((string)wp_unslash($string));
            }
        }
        $rewrite = listar_theme_option('rewrite');
        if(!empty($query_string)) {
            return sprintf('%s/%s/?%s', home_url(), $rewrite, implode('&', $query_string));
        } else {
            return sprintf('%s/%s', home_url(), $rewrite);
        }
    }
}

if (!function_exists('listar_get_pagination')) {
    /**
     * Pagination
     * @return string
     */
    function listar_get_pagination()
    {
        $allowed_tags = [
            'span' => [
                'class' => []
            ],
            'i' => [
                'class' => [],
                'aria-hidden' => []
            ],
            'a' => [
                'class' => [],
                'href' => []
            ]
        ];

        $args = [
            'before_page_number'    => '<span class="page-content">',
            'after_page_number'     => '</span>',
            'prev_text' => '<span class="page-content"><i class="fa fa-arrow-left" aria-hidden="true"></i> ' . __('Previous', 'listar_wp') . '</span>',
            'next_text' => '<span class="page-content">' . __('Next', 'listar_wp') . ' <i class="fa fa-arrow-right" aria-hidden="true"></i></span>',
        ];

        return printf('<nav class="pagination">%s</nav>', wp_kses(paginate_links($args), $allowed_tags));
    }
}

if(!function_exists('get_the_excerpt_custom')) {
    /**
     * Excerpt custom
     * @param integer $limit
     * @param string $source
     * @return string
     */
    function get_the_excerpt_custom($limit, $source = null)
    {
        $excerpt = $check_length = $source == "content" ? get_the_content() : get_the_excerpt();
        $excerpt = preg_replace(" (\[.*?\])", '', $excerpt);
        $excerpt = strip_shortcodes($excerpt);
        $excerpt = strip_tags($excerpt);
        $excerpt = substr($excerpt, 0, $limit);
        $excerpt = substr($excerpt, 0, strripos($excerpt, " "));
        $excerpt = trim(preg_replace('/\s+/', ' ', $excerpt));
        $excerpt = $excerpt . (strlen($check_length) <= $limit ? '' : '...');
    
        return $excerpt;
    }
}

