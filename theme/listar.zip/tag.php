<?php get_header(); ?>
    <?php
    get_sidebar('breadcrumb');
    $tags_list = get_the_tag_list( '', __( ', ', 'listar_wp' ) );
    ?>
<?php get_footer(); ?>