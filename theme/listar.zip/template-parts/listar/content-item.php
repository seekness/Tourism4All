<div class="d-flex flex-column place-item">
    <div class="thumb">
        <div class='gradient'></div>
        <?php $status =  esc_attr(get_post_meta(get_the_ID(), 'status', TRUE));?>
        <?php if($status) { ?>
            <span class="badge-custom status badge badge-pill badge-primary">
                    <?php echo esc_attr($status) ;?>
                </span>
        <?php } ?>
        <?php if (get_the_post_thumbnail() !== '' ) {
            the_post_thumbnail( 'thumb' );
        }
        ?>
        <div class="heart"><i class="far fa-heart"></i></div>
    </div>
    <div class='place-info mg-t-5'>
        <div class="d-flex flex-column">
            <?php listar_the_categories_list('<span class="desc text-ellipsis">', '</span>');?>
            <?php the_title( '<span class="title text-ellipsis"><a class="text-dark-blue" href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></span>' ); ?>
            <span class="rate d-flex">
                <span class="badge-tag-custom wd-30 badge badge-primary mg-r-5">
                    <?php echo esc_attr(get_post_meta(get_the_ID(), 'rating_avg', TRUE)) ?>
                </span>
                <?php listar_the_rating_icon();?>
            </span>
            <span class="place-caption"></span>
            <span class="sub-desc text-ellipsis"><?php echo esc_attr(get_post_meta(get_the_ID(), 'address', TRUE)) ?></span>
            <span class="sub-desc text-ellipsis"><?php echo esc_attr(get_post_meta(get_the_ID(), 'phone', TRUE)) ?></span>
            <span class="sub-desc text-ellipsis"></span>
        </div>
    </div>
</div>