<?php
$features = listar_get_features(get_the_ID());
// Open Hours
$opening_hour = listar_get_opening_hour(get_post_meta(get_the_ID()));
$day_number = (int)date('w');
$week = (int)date('w');
if($week === 0 ) $week = 6;
else if($week === 6) $week = 0;
else $week = $week - 1;

// Author
$author_id = get_the_author_meta('ID');
$author_name = get_the_author_meta('display_name');
$author_photo = get_avatar_url($author_id);

$galleries_str_ids = get_post_meta(get_the_ID(), 'gallery', true);
$ids = explode(',', $galleries_str_ids);
$images = [];
if(is_array($ids) && !empty($ids)) {
    foreach ($ids as $attachment_id) {
        $images[] = [
            'full' => ['url' => wp_get_attachment_url($attachment_id) ?? ''],
            'thumb' => ['url' => wp_get_attachment_thumb_url($attachment_id) ?? '']
        ];
    }
}

$map_use = listar_theme_option('map_use');
$gmap_key = listar_theme_option('gmap_key');
$longitude = get_post_meta(get_the_ID(), 'longitude', TRUE);
$latitude = get_post_meta(get_the_ID(), 'latitude', TRUE);
$col_format_6 = $longitude && $latitude && $map_use && $gmap_key;

$socials = get_post_meta(get_the_ID(), 'social_network', TRUE);
$socials = json_decode($socials);

$rating_sum = 0;
$ratings_list = get_post_meta(get_the_ID(), 'rating_meta', TRUE);
$ratings_list = json_decode($ratings_list);

$star_arr = [
    'one_star' => 0,
    'two_star' => 0,
    'thr_star' => 0,
    'fou_star' => 0,
    'fiv_star' => 0
];

if($ratings_list) {
    $rating_sum += $ratings_list->{'1'};
    $rating_sum += $ratings_list->{'2'};
    $rating_sum += $ratings_list->{'3'};
    $rating_sum += $ratings_list->{'4'};
    $rating_sum += $ratings_list->{'5'};

    $one_star = round($ratings_list->{'1'} / $rating_sum * 100, 2);
    $two_star = round($ratings_list->{'2'} / $rating_sum * 100, 2);
    $thr_star = round($ratings_list->{'3'} / $rating_sum * 100, 2);
    $fou_star = round($ratings_list->{'4'} / $rating_sum * 100, 2);
    $fiv_star = round($ratings_list->{'5'} / $rating_sum * 100, 2);

    $star_arr = [
        'one_star' => $one_star,
        'two_star' => $two_star,
        'thr_star' => $thr_star,
        'fou_star' => $fou_star,
        'fiv_star' => $fiv_star,
    ];
}

function renderFullDay($key) {
    switch($key) {
        case 'mon':
            return _e('Monday', 'listar_wp');
        case 'tue':
            return _e('Tuesday', 'listar_wp');
        case 'wed':
            return _e('Wednesday', 'listar_wp');
        case 'thu':
            return _e('Thursday', 'listar_wp');
        case 'fri':
            return _e('Friday', 'listar_wp');
        case 'sat':
            return _e('Saturday', 'listar_wp');
        case 'sun':
            return _e('Sunday', 'listar_wp');
    }
}
?>
<div class="content-p-warpper">
    <div class="row place-detail-gallery">
        <div class="listar-background">
            <div style="width: 100%">
                <ul id="images_gallery" class='ls-gallery'>
                    <li data-thumb="<?php echo get_the_post_thumbnail_url(get_the_ID(), 'thumb');?>">
                        <img src="<?php echo get_the_post_thumbnail_url(get_the_ID(), 'large');?>" class="gallery-img-main" />
                    </li>
                    <?php if(!empty($images)) { ?>
                        <?php foreach($images as $image) { ?>
                        <li data-thumb="<?php echo esc_url($image['full']['url']);?>"
                            data-src="<?php echo esc_url($image['full']['url']);?>">
                            <img src="<?php echo esc_url($image['full']['url']);?>" class="gallery-img-main" />
                        </li>
                        <?php } ?>
                    <?php } ?>
                </ul>
            </div>
        </div>
    </div>
    <div class="container bg-transparent place-detail-content">
        <div class="col-md-8 main-content bg-main-content bd-r-main">
            <div class='render-utility row pd-10'>
                <div class="<?php echo  esc_attr($col_format_6) ? 'col-md-6' : 'col-md-12'; ?>">
                    <div class="summary-info pd-10">
                        <?php the_title( '<div class="title-post">', '</div>' ); ?>
                        <?php listar_the_categories_list('<span class="desc-place-detail pd-b-5">', '</span>', true, false);?>
                        <div class="summary-rate">
                            <div class="rate d-flex author-views align-items-center">
                                <span class="place-rate-number badge badge-primary mg-r-10">
                                    <?php echo esc_attr(get_post_meta(get_the_ID(), 'rating_avg', TRUE)) ?>
                                </span>
                                <?php listar_the_rating_icon();?>
                                <span class="rate-count">
                                    <?php echo esc_attr(get_post_meta(get_the_ID(), 'rating_counting', TRUE)) ?>
                                </span>
                                <span class="line">|</span>
                                <i class="far fa-clock"></i>
                                <div class="time"><?php _e('Posted', 'listar_wp') . printf(' %1$s', human_time_diff(get_the_time('U'), current_time('U')) . ' ' . __('ago', 'listar_wp'))?></div>
                            </div>
                        </div>
                    </div>
                    <div>
                        <ul class="list-unstyled">
                            <li class="d-flex align-items-center justify-content-between ht-40 place-detail-info mg-b-10">
                                <div class="icon-place-list">
                                    <i class="fas fa-map-marker-alt"></i>
                                </div>
                                <div class='flex-grow-1 mg-l-10'>
                                    <div class='title-info-place'><?php _e('Address', 'listar_wp'); ?></div>
                                    <div class='addr-info-place'><?php echo esc_attr(get_post_meta(get_the_ID(), 'address', TRUE)) ?></div>
                                </div>
                            </li>
                            <li class="d-flex align-items-center justify-content-between ht-40 place-detail-info mg-b-10">
                                <div class="icon-place-list">
                                    <i class="fas fa-mobile-alt"></i>
                                </div>
                                <div class='flex-grow-1 mg-l-10'>
                                    <div class='title-info-place'><?php _e('Tel', 'listar_wp');?></div>
                                    <div class='addr-info-place'><?php echo esc_attr(get_post_meta(get_the_ID(), 'phone', TRUE)) ?></div>
                                </div>
                            </li>
                            <li class="d-flex align-items-center justify-content-between ht-40 place-detail-info mg-b-10">
                                <div class="icon-place-list">
                                    <i class="fas fa-envelope"></i>
                                </div>
                                <div class='flex-grow-1 mg-l-10'>
                                    <div class='title-info-place'><?php _e('Email', 'listar_wp');?></div>
                                    <div class='addr-info-place'><?php echo esc_attr(get_post_meta(get_the_ID(), 'email', TRUE)) ?></div>
                                </div>
                            </li>
                            <li class="d-flex align-items-center justify-content-between ht-40 place-detail-info mg-b-10">
                                <div class="icon-place-list ">
                                    <i class="fas fa-globe"></i>
                                </div>
                                <div class='flex-grow-1 mg-l-10'>
                                    <div class='title-info-place'><?php _e('Website', 'listar_wp');?></div>
                                    <div class='addr-info-place'><?php echo esc_attr(get_post_meta(get_the_ID(), 'website', TRUE)) ?></div>
                                </div>
                            </li>
                            <li class="d-flex align-items-center justify-content-between ht-40 place-detail-info mg-b-10">
                                <div class="icon-place-list">
                                    <i class="fas fa-clock"></i>
                                </div>
                                <div class='flex-grow-1 mg-l-10'>
                                    <div class='title-info-place'><?php _e('Open Hours', 'listar_wp');?></div>
                                    <div class='addr-info-place'>
                                        <?php if(isset($opening_hour[$week])) {
                                            foreach ($opening_hour[$week]['schedule'] as $schedule) {
                                                echo sprintf('%s - %s', $schedule['start'], $schedule['end']).'<br/>';
                                            }
                                        }
                                        ?>
                                    </div>
                                </div>
                                <a data-toggle="collapse" href="#collapseExample" class="toggleOpenHour"><i class="fas fa-chevron-down"></i></a>
                            </li>
                        </ul>
                        <div class="collapse mg-t-5 pd-20" id="collapseExample"></div>
                    </div>
                </div>
                <?php
                    if($longitude && $latitude && $map_use && $gmap_key) {
                ?>
                <div class="col-md-6" style="min-height: 320px;">
                    <iframe width="100%" height="100%" frameborder="0" style="border:0" loading="lazy" allowfullscreen 
                        src="https://www.google.com/maps/embed/v1/place?q=<?php echo esc_attr($latitude) . ',' . esc_attr($longitude); ?>&key=<?php echo esc_attr($gmap_key);?>"></iframe>
                </div>
                <?php } ?>
            </div>
            <div class="pd-l-20 socials-network">
                <?php echo empty($socials->facebook) ? '' : '<a href="' . esc_attr($socials->facebook) . '" target="_blank"><i class="fab fa-facebook-square" color="#3A5998"></i></a>'; ?>
                <?php echo empty($socials->twitter) ? '' : '<a href="' . esc_attr($socials->twitter) . '" target="_blank"><i class="fab fa-twitter-square" color="#4dabf7"></i></a>'; ?>
                <?php echo empty($socials->google) ? '' : '<a href="' . esc_attr($socials->google) . '" target="_blank"><i class="fab fa-google-plus-square" color="#d34836"></i></a>'; ?>
                <?php echo empty($socials->pinterest) ? '' : '<a href="' . esc_attr($socials->pinterest) . '" target="_blank"><i class="fab fa-pinterest-square" color="#cb2027"></i></a>'; ?>
                <?php echo empty($socials->tumblr) ? '' : '<a href="' . esc_attr($socials->tumblr) . '" target="_blank"><i class="fab fa-tumblr-square" color="#35465c"></i></a>'; ?>
                <?php echo empty($socials->linkedin) ? '' : '<a href="' . esc_attr($socials->linkedin) . '" target="_blank"><i class="fab fa-linkedin" color="#0274b3"></i></a>'; ?>
                <?php echo empty($socials->youtube) ? '' : '<a href="' . esc_attr($socials->youtube) . '" target="_blank"><i class="fab fa-youtube-square" color="#ff0016"></i></a>'; ?>
                <?php echo empty($socials->instagram) ? '' : '<a href="' . esc_attr($socials->instagram) . '" target="_blank"><i class="fab fa-instagram" color="#f85148"></i></a>'; ?>
                <?php echo empty($socials->flickr) ? '' : '<a href="' . esc_attr($socials->flickr) . '" target="_blank"><i class="fab fa-flickr" color="#ff0084"></i></a>'; ?>
            </div>
            <div class='pd-20'>
                <h5 class="grid-title"><?php __('Description', 'listar_wp');?></h5>
                <p class="description">
                    <?php the_excerpt();?>
                </p>
            </div>
            <?php if(!empty($features)) { ?>
            <div class="pd-20">
                <div class="grid-title mg-b-20"><?php __('Features', 'listar_wp');?></div>
                <ul class="ls-tag">
                    <?php foreach ($features as $term) {
                        $icon = get_term_meta($term->term_id, 'icon', true);
                        echo '<li class=\'facility\'> <button><i class="fa '.$icon.'" aria-hidden="true"></i>'.$term->name.'</button></li>';
                    }
                    ?>
                </ul>
            </div>
            <?php } ?>
            <div class="pd-20">
                <div class="grid-title mg-b-20"><?php _e('Rating', 'listar_wp');?></div>
                <div class="col-md-7">
                    <div class="d-flex align-items-center">
                        <div class="number-rate-review">
                            <div class="text-primary"><?php echo esc_attr(get_post_meta(get_the_ID(), 'rating_avg', TRUE)) ?></div>
                            <div><?php _e('out of 5', 'listar_wp');?></div>
                        </div>
                        <ul class="list-unstyled star-review flex-grow-1">
                            <li class="d-flex align-items-center">
                                <div class="star">
                                    <i class="fa fa-star " color="#9B9B9B"></i>
                                    <i class="fa fa-star " color="#9B9B9B"></i>
                                    <i class="fa fa-star " color="#9B9B9B"></i>
                                    <i class="fa fa-star " color="#9B9B9B"></i>
                                    <i class="fa fa-star " color="#9B9B9B"></i>
                                </div>
                                <div class="percentRate flex-grow-1">
                                    <div class="active bg-primary" style="width:<?php echo esc_attr($star_arr['fiv_star']); ?>%"></div>
                                </div>
                            </li>
                            <li class="d-flex align-items-center">
                                <div class="star">
                                    <i class="fa fa-star active" color="#fdc60a"></i>
                                    <i class="fa fa-star " color="#9B9B9B"></i>
                                    <i class="fa fa-star " color="#9B9B9B"></i>
                                    <i class="fa fa-star " color="#9B9B9B"></i>
                                    <i class="fa fa-star " color="#9B9B9B"></i>
                                </div>
                                <div class="percentRate flex-grow-1">
                                    <div class="active bg-primary" style="width:<?php echo esc_attr($star_arr['fou_star']); ?>%"></div>
                                </div>
                            </li>
                            <li class="d-flex align-items-center">
                                <div class="star">
                                    <i class="fa fa-star active" color="#fdc60a"></i>
                                    <i class="fa fa-star active" color="#fdc60a"></i>
                                    <i class="fa fa-star " color="#9B9B9B"></i>
                                    <i class="fa fa-star " color="#9B9B9B"></i>
                                    <i class="fa fa-star " color="#9B9B9B"></i>
                                </div>
                                <div class="percentRate flex-grow-1">
                                    <div class="active bg-primary" style="width:<?php echo esc_attr($star_arr['thr_star']); ?>%"></div>
                                </div>
                            </li>
                            <li class="d-flex align-items-center">
                                <div class="star">
                                    <i class="fa fa-star active" color="#fdc60a"></i>
                                    <i class="fa fa-star active" color="#fdc60a"></i>
                                    <i class="fa fa-star active" color="#fdc60a"></i>
                                    <i class="fa fa-star " color="#9B9B9B"></i>
                                    <i class="fa fa-star " color="#9B9B9B"></i>
                                </div>
                                <div class="percentRate flex-grow-1">
                                    <div class="active bg-primary" style="width:<?php echo esc_attr($star_arr['two_star']); ?>%"></div>
                                </div>
                            </li>
                            <li class="d-flex align-items-center">
                                <div class="star">
                                    <i class="fa fa-star active" color="#fdc60a"></i>
                                    <i class="fa fa-star active" color="#fdc60a"></i>
                                    <i class="fa fa-star active" color="#fdc60a"></i>
                                    <i class="fa fa-star active" color="#fdc60a"></i>
                                    <i class="fa fa-star " color="#9B9B9B"></i>
                                </div>
                                <div class="percentRate flex-grow-1">
                                    <div class="active bg-primary" style="width:<?php echo esc_attr($star_arr['one_star']); ?>%"></div>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="pd-20 bd-t pd-t-10">
                <?php if (comments_open() || get_comments_number() != '0') : comments_template(); endif; ?>
            </div>
        </div>
        <div class="col-md-4 sub-content">
            <div class="pd-20 bg-main-content bd-r-main open-hour">
                <div id="content-open-hour">
                    <div class="grid-title pd-b-20"><?php _e('Open Hours', 'listar_wp');?></div>
                    <table class='table table-open-hour'>
                        <?php if(is_array($opening_hour) && !empty($opening_hour)) { ?>
                            <?php foreach ($opening_hour as $row) { ?>
                            <tr>
                                <td <?php if($day_number == $row['day_of_week']) echo 'class="text-primary"'; ?>><?php echo renderFullDay($row['key']); ?></td>
                                <td class="text-right<?php if($day_number == $row['day_of_week']) echo ' text-primary'; ?>">
                                    <?php if(isset($row['schedule']) && is_array($row['schedule']) && !empty($row['schedule'])) {
                                        foreach($row['schedule'] as $schedule) {
                                            echo sprintf('%s - %s', $schedule['start'], $schedule['end']).'<br/>';
                                        }
                                    } ?>
                                </td>
                            </tr>
                            <?php } ?>
                        <?php } ?>
                    </table>
                </div>
            </div>
            <?php if ( is_active_sidebar( 'listar-detail-right-sidebar' ) ) { ?>
                <?php dynamic_sidebar( 'listar-detail-right-sidebar' ); ?>
            <?php } ?>
        </div>
    </div>
    <?php
    wp_link_pages(
        array(
            'before' => '<div class="page-links">' . __( 'Pages:', 'listar_wp' ),
            'after'  => '</div>',
        )
    );
    ?>
</div>