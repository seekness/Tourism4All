<div class="container">
    <div class="title-page">
        <?php the_title('<div class="title-header text-center">', '</div>'); ?>
    </div>
    <div class="content-page">
        <div class="desc-post">
            <?php the_content(); ?>
        </div>
    </div>
</div>