<?php
// Author
$author_id = $post->post_author;
$author_name = get_the_author_meta('display_name', $author_id);
$author_photo = get_avatar_url($author_id);
?>
<div class="row">
    <div class="listar-background">
        <?php if (get_the_post_thumbnail() !== '' ) {
            the_post_thumbnail( 'large' );
        }
        ?>
    </div>
</div>
<div class="bg-main-content row">
    <div class="container">
        <div class="blog-details">
            <?php
            if (is_single()) : the_title('<h1 class="title py-3">', '</h1>'); endif;
            ?>
            <div class="d-flex justify-content-between align-items-center ht-60 author">
                <img src="<?php echo esc_attr($author_photo);?>">
                <div class="flex-grow-1 mg-l-5">
                    <div class="author-name"><?php echo esc_attr($author_name); ?></div>
                    <div class="author-views"><?php echo human_time_diff(get_the_time('U'), current_time('U')) . ' ago'; ?>&nbsp;</div>
                </div>
                <span class="sub-desc"><?php echo get_the_date(); ?></span>
            </div>
            <div class="content-blog">
                <?php the_content(); ?>
            </div>
            <div class="bd-t">
                <?php if (comments_open() || get_comments_number() != '0') : comments_template(); endif; ?>
            </div>
        </div>
    </div>
</div>